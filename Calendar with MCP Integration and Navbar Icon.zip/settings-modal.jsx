import React, { useState } from 'react';
import { X, Eye, EyeOff, Save, Trash2 } from 'lucide-react';
import { Button } from './button';
import { Card, CardContent, CardHeader, CardTitle } from './card';
import { Input } from './input';
import { Label } from './label';

const SettingsModal = ({ isOpen, onClose, onSave }) => {
  const [mcpSettings, setMcpSettings] = useState({
    googleCalendar: {
      clientId: '',
      clientSecret: '',
      accessToken: '',
      refreshToken: ''
    },
    outlookCalendar: {
      clientId: '',
      clientSecret: '',
      accessToken: '',
      refreshToken: ''
    },
    openaiApiKey: '',
    elevenLabsApiKey: ''
  });

  const [showSecrets, setShowSecrets] = useState({});

  const handleInputChange = (provider, field, value) => {
    setMcpSettings(prev => ({
      ...prev,
      [provider]: {
        ...prev[provider],
        [field]: value
      }
    }));
  };

  const handleDirectInputChange = (field, value) => {
    setMcpSettings(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const toggleSecretVisibility = (key) => {
    setShowSecrets(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const handleSave = () => {
    if (onSave) {
      onSave(mcpSettings);
    }
    onClose();
  };

  const clearProvider = (provider) => {
    setMcpSettings(prev => ({
      ...prev,
      [provider]: {
        clientId: '',
        clientSecret: '',
        accessToken: '',
        refreshToken: ''
      }
    }));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <CardTitle className="text-xl font-semibold">Settings</CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="h-8 w-8 p-0"
          >
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Google Calendar Settings */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Google Calendar</h3>
              <Button
                variant="outline"
                size="sm"
                onClick={() => clearProvider('googleCalendar')}
              >
                <Trash2 className="h-4 w-4 mr-1" />
                Clear
              </Button>
            </div>
            <div className="grid grid-cols-1 gap-4">
              <div>
                <Label htmlFor="google-client-id">Client ID</Label>
                <Input
                  id="google-client-id"
                  type="text"
                  value={mcpSettings.googleCalendar.clientId}
                  onChange={(e) => handleInputChange('googleCalendar', 'clientId', e.target.value)}
                  placeholder="Enter Google Calendar Client ID"
                />
              </div>
              <div>
                <Label htmlFor="google-client-secret">Client Secret</Label>
                <div className="relative">
                  <Input
                    id="google-client-secret"
                    type={showSecrets['google-secret'] ? 'text' : 'password'}
                    value={mcpSettings.googleCalendar.clientSecret}
                    onChange={(e) => handleInputChange('googleCalendar', 'clientSecret', e.target.value)}
                    placeholder="Enter Google Calendar Client Secret"
                    className="pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3"
                    onClick={() => toggleSecretVisibility('google-secret')}
                  >
                    {showSecrets['google-secret'] ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>
            </div>
          </div>

          {/* Outlook Calendar Settings */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Outlook Calendar</h3>
              <Button
                variant="outline"
                size="sm"
                onClick={() => clearProvider('outlookCalendar')}
              >
                <Trash2 className="h-4 w-4 mr-1" />
                Clear
              </Button>
            </div>
            <div className="grid grid-cols-1 gap-4">
              <div>
                <Label htmlFor="outlook-client-id">Client ID</Label>
                <Input
                  id="outlook-client-id"
                  type="text"
                  value={mcpSettings.outlookCalendar.clientId}
                  onChange={(e) => handleInputChange('outlookCalendar', 'clientId', e.target.value)}
                  placeholder="Enter Outlook Calendar Client ID"
                />
              </div>
              <div>
                <Label htmlFor="outlook-client-secret">Client Secret</Label>
                <div className="relative">
                  <Input
                    id="outlook-client-secret"
                    type={showSecrets['outlook-secret'] ? 'text' : 'password'}
                    value={mcpSettings.outlookCalendar.clientSecret}
                    onChange={(e) => handleInputChange('outlookCalendar', 'clientSecret', e.target.value)}
                    placeholder="Enter Outlook Calendar Client Secret"
                    className="pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3"
                    onClick={() => toggleSecretVisibility('outlook-secret')}
                  >
                    {showSecrets['outlook-secret'] ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>
            </div>
          </div>

          {/* API Keys */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">API Keys</h3>
            <div className="grid grid-cols-1 gap-4">
              <div>
                <Label htmlFor="openai-key">OpenAI API Key</Label>
                <div className="relative">
                  <Input
                    id="openai-key"
                    type={showSecrets['openai-key'] ? 'text' : 'password'}
                    value={mcpSettings.openaiApiKey}
                    onChange={(e) => handleDirectInputChange('openaiApiKey', e.target.value)}
                    placeholder="sk-..."
                    className="pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3"
                    onClick={() => toggleSecretVisibility('openai-key')}
                  >
                    {showSecrets['openai-key'] ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>
              <div>
                <Label htmlFor="elevenlabs-key">ElevenLabs API Key</Label>
                <div className="relative">
                  <Input
                    id="elevenlabs-key"
                    type={showSecrets['elevenlabs-key'] ? 'text' : 'password'}
                    value={mcpSettings.elevenLabsApiKey}
                    onChange={(e) => handleDirectInputChange('elevenLabsApiKey', e.target.value)}
                    placeholder="Enter ElevenLabs API Key"
                    className="pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3"
                    onClick={() => toggleSecretVisibility('elevenlabs-key')}
                  >
                    {showSecrets['elevenlabs-key'] ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>
            </div>
          </div>

          {/* Save Button */}
          <div className="flex justify-end space-x-2 pt-4">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button onClick={handleSave}>
              <Save className="h-4 w-4 mr-1" />
              Save Settings
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SettingsModal;

