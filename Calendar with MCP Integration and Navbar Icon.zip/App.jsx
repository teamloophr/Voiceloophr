import React, { useState, useEffect } from 'react';
import Navbar from './components/ui/navbar';
import EventCalendar from './components/ui/event-calendar';
import SettingsModal from './components/ui/settings-modal';
import './App.css';

function App() {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [events, setEvents] = useState([
    {
      id: 1,
      title: 'Team Meeting',
      description: 'Weekly team sync',
      start_time: new Date(2025, 7, 26, 10, 0).toISOString(),
      end_time: new Date(2025, 7, 26, 11, 0).toISOString(),
      location: 'Conference Room A',
      attendees: ['john@example.com', 'jane@example.com']
    },
    {
      id: 2,
      title: 'Project Review',
      description: 'Q3 project review meeting',
      start_time: new Date(2025, 7, 28, 14, 0).toISOString(),
      end_time: new Date(2025, 7, 28, 15, 30).toISOString(),
      location: 'Virtual',
      attendees: ['manager@example.com']
    },
    {
      id: 3,
      title: 'Client Call',
      description: 'Discussion about new requirements',
      start_time: new Date(2025, 7, 30, 9, 0).toISOString(),
      end_time: new Date(2025, 7, 30, 10, 0).toISOString(),
      location: 'Virtual',
      attendees: ['client@example.com']
    }
  ]);

  // Apply dark mode class to document
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const handleThemeToggle = () => {
    setIsDarkMode(!isDarkMode);
  };

  const handleCalendarToggle = (isOpen) => {
    setIsCalendarOpen(isOpen);
  };

  const handleSettingsToggle = () => {
    setIsSettingsOpen(!isSettingsOpen);
  };

  const handleEventClick = (event) => {
    alert(`Event: ${event.title}\nTime: ${new Date(event.start_time).toLocaleString()}\nDescription: ${event.description}`);
  };

  const handleDateClick = (date) => {
    console.log('Date clicked:', date);
    // Here you could open an event creation modal
  };

  const handleAddEvent = () => {
    alert('Add Event functionality would open a modal here');
    // Here you could open an event creation modal
  };

  const handleSettingsSave = (settings) => {
    console.log('Settings saved:', settings);
    // Here you would save the settings to your backend or local storage
    localStorage.setItem('voiceloophr-settings', JSON.stringify(settings));
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar
        onCalendarClick={handleCalendarToggle}
        onSettingsClick={handleSettingsToggle}
        isDarkMode={isDarkMode}
        onThemeToggle={handleThemeToggle}
      />
      
      <main className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4">VoiceLoopHR Calendar</h1>
          <p className="text-lg text-muted-foreground">
            Sophisticated calendar with MCP integration and smart voice communication
          </p>
        </div>

        {isCalendarOpen && (
          <div className="mb-8">
            <EventCalendar
              events={events}
              onEventClick={handleEventClick}
              onDateClick={handleDateClick}
              onAddEvent={handleAddEvent}
            />
          </div>
        )}

        {!isCalendarOpen && (
          <div className="text-center py-16">
            <p className="text-muted-foreground mb-4">
              Click the calendar icon in the navigation bar to view your calendar
            </p>
            <button
              onClick={() => setIsCalendarOpen(true)}
              className="text-primary hover:underline"
            >
              Open Calendar
            </button>
          </div>
        )}
      </main>

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        onSave={handleSettingsSave}
      />
    </div>
  );
}

export default App;
