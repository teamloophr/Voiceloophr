import React, { useState } from 'react';
import { Calendar, Settings, Moon, Sun, User } from 'lucide-react';
import { Button } from './button';

const Navbar = ({ onCalendarClick, onSettingsClick, isDarkMode, onThemeToggle }) => {
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);

  const handleCalendarClick = () => {
    setIsCalendarOpen(!isCalendarOpen);
    if (onCalendarClick) {
      onCalendarClick(!isCalendarOpen);
    }
  };

  return (
    <nav className="w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 h-14 flex items-center justify-between">
        {/* Logo/Brand */}
        <div className="flex items-center space-x-2">
          <div className="font-bold text-xl">VoiceLoopHR</div>
        </div>

        {/* Navigation Items */}
        <div className="flex items-center space-x-2">
          {/* Calendar Icon */}
          <Button
            variant={isCalendarOpen ? "default" : "ghost"}
            size="sm"
            onClick={handleCalendarClick}
            className="relative"
            aria-label="Toggle Calendar"
          >
            <Calendar className="h-4 w-4" />
            {isCalendarOpen && (
              <div className="absolute -top-1 -right-1 h-2 w-2 bg-primary rounded-full" />
            )}
          </Button>

          {/* User Profile */}
          <Button
            variant="ghost"
            size="sm"
            aria-label="User Profile"
          >
            <User className="h-4 w-4" />
          </Button>

          {/* Settings */}
          <Button
            variant="ghost"
            size="sm"
            onClick={onSettingsClick}
            aria-label="Settings"
          >
            <Settings className="h-4 w-4" />
          </Button>

          {/* Theme Toggle */}
          <Button
            variant="ghost"
            size="sm"
            onClick={onThemeToggle}
            aria-label="Toggle Theme"
          >
            {isDarkMode ? (
              <Sun className="h-4 w-4" />
            ) : (
              <Moon className="h-4 w-4" />
            )}
          </Button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;

